# The Bandit Plugin

Plugin for the bandit template themes

Download all source code and paste to bl-plugins project